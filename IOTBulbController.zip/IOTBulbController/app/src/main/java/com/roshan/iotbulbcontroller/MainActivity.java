package com.roshan.iotbulbcontroller;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private final int LIGHT_ON = 1;
    private final int LIGHT_OFF = 0;
    private final String IOT_SHARED_PREF = "IOT_SHARED_PREF";
    private final String LIGHT_STATUS = "LIGHT_STATUS";
    private final String TAG = "LIGHT_TAG";

    private final String REFERENCE_KEY = "ledStatus";
    private final String CHILD_KEY = "ledStatus";

    private SharedPreferences preferences;
    private FirebaseDatabase rootNode;
    private DatabaseReference reference;
    private ConnectionHandler connectionHandler;
    private ValueEventListener valueEventListener;

    private TextView status_tv;
    private ImageView bulb_iv;
    private CoordinatorLayout root_lay;
    private Button control_btn;
    private ProgressBar progress_bar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        handleLightStatus();
        listenToChangesInDB();
    }

    private void init() {

        status_tv = findViewById(R.id.status_tv);
        bulb_iv = findViewById(R.id.bulb_iv);
        root_lay = findViewById(R.id.root_lay);
        control_btn = findViewById(R.id.control_btn);
        progress_bar = findViewById(R.id.progress_bar);

        preferences = getSharedPreferences(IOT_SHARED_PREF, MODE_PRIVATE);
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference(REFERENCE_KEY);
        connectionHandler = new ConnectionHandler(this);
    }

    // listeners
    private void listenToChangesInDB() {

        valueEventListener = reference.child(CHILD_KEY).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                try {

                    toggleProgressBar(false);

                    Long response = dataSnapshot.getValue(Long.class);
                    Log.d(TAG, dataSnapshot.toString());

                    Log.d(TAG, "Response from listener "+response);
                    // checking if the response is not empty
                    if (response != null) {
                        // check for the status of bulb
                        if (response == LIGHT_ON) {
                            // Bulb is ON
                            Log.d(TAG, "Response indicates that bulb is ON.");
                            toggleLightStatus(LIGHT_ON);
                        } else {
                            // Bulb is OFF
                            Log.d(TAG, "Response indicates that bulb is OFF.");
                            toggleLightStatus(LIGHT_OFF);
                        }
                    } else {
                        // response is empty
                        throw new NullPointerException("Listener response is empty");
                    }

                } catch (Exception e) {
                    Log.d(TAG, "Exception while processing listener response " + e.getMessage());
                    showSnackBar("An error occurred. Please try again");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                toggleProgressBar(false);
                showSnackBar("Unable to read the response from firebase. Please try again");
            }
        });
    }

    private void handleLightStatus() {

        // checking if the light is off.
        // If so then making the background color black and changing the button text. Default status of light is OFF.

        int light_status = preferences.getInt(LIGHT_STATUS, LIGHT_OFF);
        if (light_status == LIGHT_ON) {

            // light is ON
            root_lay.setBackgroundColor(getColor(R.color.white));
            status_tv.setText(getString(R.string.light_on));
            control_btn.setText(getString(R.string.light_off_light));
            bulb_iv.setImageDrawable(getDrawable(R.drawable.ic_light_on));

        } else {

            // light is OFF
            root_lay.setBackgroundColor(getColor(R.color.black));
            status_tv.setText(getString(R.string.light_off));
            control_btn.setText(getString(R.string.light_on_light));
            bulb_iv.setImageDrawable(getDrawable(R.drawable.ic_light_off));
        }
    }

    private void toggleLightStatus(int status) {

        preferences.edit().putInt(LIGHT_STATUS, status).apply();
        handleLightStatus();
    }

    private void updateValueInDB(int status) {

        HashMap hashMap = new HashMap();
        hashMap.put(CHILD_KEY, status);
        reference.updateChildren(hashMap);
    }

    private void showSnackBar(String message) {

        Snackbar snackbar = Snackbar.make(root_lay, message, Snackbar.LENGTH_LONG);
        snackbar.setBackgroundTint(getColor(R.color.red));
        snackbar.show();
    }

    private void toggleProgressBar(boolean showProgress) {

        if (showProgress) {

            progress_bar.setVisibility(View.VISIBLE);
        } else {

            progress_bar.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    protected void onDestroy() {

        if (valueEventListener != null) {
            // removing the listener.
            reference.child(CHILD_KEY).removeEventListener(valueEventListener);
        }
        super.onDestroy();
    }


    // on click functions.

    public void controlLight(View view) {

        // check for internet connection
        if (!connectionHandler.isConnected()) {
            showSnackBar(getString(R.string.no_internet_connection));
            return;
        }

        int light_status = preferences.getInt(LIGHT_STATUS, LIGHT_OFF);
        toggleProgressBar(true);
        if (light_status == LIGHT_OFF) {
            // light was OFF. Turn it ON
            updateValueInDB(LIGHT_ON);
        } else {
            // light was ON. Turn it OFF
            updateValueInDB(LIGHT_OFF);
        }
    }

    public void showEditDialog(View view) {

        try {

            Dialog editDialog = new Dialog(this);
            editDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            editDialog.setContentView(R.layout.dia_change_preference_values);
            editDialog.setCancelable(false);
            editDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            Button cancel_btn = editDialog.findViewById(R.id.cancel_btn);
            Button save_btn = editDialog.findViewById(R.id.save_btn);
            RadioButton turn_on_light_rb = editDialog.findViewById(R.id.turn_on_light_rb);
            RadioButton turn_off_light_rb = editDialog.findViewById(R.id.turn_off_light_rb);

            int light_status = preferences.getInt(LIGHT_STATUS, LIGHT_OFF);
            if (light_status == LIGHT_ON) {
                turn_on_light_rb.setChecked(true);
            } else {
                turn_off_light_rb.setChecked(true);
            }

            cancel_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    editDialog.dismiss();
                }
            });
            save_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (turn_on_light_rb.isChecked()) {
                        toggleLightStatus(LIGHT_ON);
                    } else {
                        toggleLightStatus(LIGHT_OFF);
                    }
                    editDialog.dismiss();
                }
            });
            editDialog.show();

        } catch (Exception e) {
            Log.d(TAG, "############# Exception while showing editDialog : " + e.getMessage());
        }
    }


}