package com.roshan.iotbulbcontroller;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;

public class ConnectionHandler {

    private Context context;

    public ConnectionHandler(Context context) {
        this.context = context;
    }

    public boolean isConnected() {

        boolean isConnected = false;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());

            if (capabilities != null) {

                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {

                    isConnected = true;
                }
            }
        }
        return isConnected;
    }
}
